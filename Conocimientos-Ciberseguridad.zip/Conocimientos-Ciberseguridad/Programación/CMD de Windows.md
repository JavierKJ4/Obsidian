Tags: #programación #cmd

El Símbolo del sistema, también llamado CMD, **forma parte de Windows y no puede ser desinstalado**. Es una herramienta que, mediante comandos, **permite realizar acciones avanzadas**. Si bien puede parecer a la Terminal de GNU/Linux, el CMD no es tan potente.

Una manera de abrir el Símbolo del sistema es pulsando las teclas Win + R y escribir CMD

Comandos para hacer scripts:

>@echo off 

Elimina las lineas de la ubicación.

>echo "algo"

Imprime en pantalla.

>set variable

Declara una variable.

>set/p 

Declara una variable que el usuario escribe

>set/a 

Declara una variable mediante una operación matematica.

>pause

Detiene el codigo para que no se cierre.

>if y else

Funcionan con () y hay que dejar los espacios bien puestos.

>pause>nul 

Detiene el codigo y elimina el mensaje(nota enviar a nul borra el output).

Nota: Las variables cuando las llamas se escriben entre porcentajes (%variable%).

Operadores: 
* LSS (menor que)
* GTR (mayor que)
* LEO (menor o igual)
* GEQ (mayor o igual)
* == (igual que)
* != (distinto de)

> color 

Cambia el color de las letras y el fondo.

>title

Cambia el nombre de la ventana.

>goto

Es como un jump y te lleva al nombre que pongas con : antes.
Ejemplo: goto comida (Esto salta hasta la parte del codigo donde esté :comida)
Se puede utilizar para hacer bucles.

>exit

Cierra el programa.

>md

Crea una carpeta.

>rd

Elimina una carpeta.

>del C:/ /F /q

Peligro esto elimina el disco C:/ sin preguntar si estas seguro.

>if exist 

Verifica si existe una carpeta con ese nombre.

Nota: El simbolo > cambia el contenido de un archivo y >> agrega contenido a un archivo.

>for %variable% in (inicio,aumento,fin) do (acción)

