Tags: #programación 

```bash
lsattr (te permite ver permisos especiales)
chattr +i archivo (agrega el permiso especial inmutable)
short (ordena alfabeticamente un output)
unig -u (elimina los duplicados)
tr 'caracter' 'otro' (sustituye un caracter por otro)
base64 (convierte a base64, con -d desencripta)
xxd (convierte a hexadecimal, -r desencripta)
diff archivo otro (te saca las diferencias)
```