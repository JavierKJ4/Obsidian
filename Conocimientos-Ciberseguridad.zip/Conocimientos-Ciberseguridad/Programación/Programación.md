Tags: #programación

Se divide en diferentes lenguajes:
* [[CMD de Windows]]
* 