Tags: #Docker 

Actualizar y instalar docker
```bash
sudo apt update -y && sudo apt install docker.io -y
```


Habilitar docker
```bash
sudo systemctl enable docker --now
```


Verificar si se instalo correctamente
```bash
sudo docker -v
```


Agregar a el usuario kali al grupo docker
```bash
sudo usermod -aG docker kali
```

Cerrar la sesion

Reiniciar el servicio de docker
```bash
sudo systemctl restart docker
```

