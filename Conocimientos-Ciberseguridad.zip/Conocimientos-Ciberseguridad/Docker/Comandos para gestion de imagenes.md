Tags: #Docker 

>docker --help


>docker images

Muestra las imagenes que tienes almacenadas

>docker search nombre

Busca imagenes en dockerhub para descargarla.

>docker pull hello-world

Descarga una imagen con el nombre hello-world

>docker rmi nombre

Elimina una imagen.
