Tags: #Docker 

Es redirigir lo que tienes en un contenedor por un puerto a un puerto de tu pc anfitriona para asi poder verlo, puedes decirle a tu pc que todo lo que venga por el puerto 33(ejemplo) de tu pc se envie al puerto 80(ejemplo) de tu contenedor y viceversa pq ahi tienes corriendo el servicio web y esto lo haria visible para todos.

>docker run -p 33:80 (nombre_imagen) 