Tags: #Docker 

>docker network ls

Lista las redes creadas.

>docker network create nombre_red

* --driver nombre(Puedes elegir el tipo de driver: bridge, host, none, overlay, macvlan, ipvlan)

>docker network inspect nombre_red

Ves informacion de la red como su IP.

>docker network rm nombre_red

Elimina una red.

>docker network connect nombre_red ID_cont

Conecta un contenedor a una red.
* disconnect (desconecta un contenedor de una red)
>docker network prune 

Elimina las redes que no tienen contenedores conectados.


