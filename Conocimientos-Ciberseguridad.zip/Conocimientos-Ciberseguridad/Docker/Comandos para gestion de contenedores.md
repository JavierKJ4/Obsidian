Tags: #Docker 

>docker create nombre_imagen --name nomb_contenedor

Crea un contenedor con el nombre de la imagen que pusiste.
* --network nombre_red (agrega el contenedor a una red)

>docker ps -a

Muestra los contenedores, los que estan corriendo y los que no.

>docker run nombre_imagen

Es la union del docker pull, docker create, docker start, es decir si no tienes la imgen la descarga, crea el contenedor y lo corre.
* -it (devuelve una consola del contenedor.)
* -d (se ejecuta en segundo plano)
* sleep infinity (mantiene el contenedor corriendo para siempre o hasta que lo detengas)

>docker stop nombre

>docker restart nombre

>docker logs

Muestra los logs del contenedor.
* -f (lo muestra en tiempo real)

>docker exec nombre_cont comando

Ejecuta un comando en un contenedor pero el contenedor tiene que estar corriendo.

>docker exec -it nombre_cont bash

Devuelve una consola del contendor.

>docker rm ID

Elimina un contenedor