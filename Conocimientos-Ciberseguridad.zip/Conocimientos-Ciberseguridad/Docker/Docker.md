Tags: #Docker

Una imagen en docker es un paquete ligero que contiene todo lo que necesita una aplicacion para ejecutarse, ya sea dependencias, librerias y demas, 
Dockerhub almacena imagenes que puedes descargar.

Un contenedor es unidad estandar de sofware que empaqueta el software y todas sus dependencias para poder ejecutarse, utilizando el kernel del sistema operativo anfitrion.

Un volumen es un mecanismo para persistir y contener datos, los volumenes pueden ser usados por varios contenedores, los volumenes estan en la maquina anfitriona y los contenedores los consultan.


Contenido:
* [[Instalacion de Docker.io]]
* [[Instalacion de Docker-ce]]
* [[Comandos para gestion de imagenes]]
* [[Comandos para gestion de contenedores]]
* [[Comandos para gestion de redes de contenedores]]
* [[Mapeo de puertos]]


Seguridad en Docker:
* --memory="1g" (maximo de memoria que puede consumir un contenedor)
* --cpus="2" (Numero maximo de nucleos que va a utilizar)
* --cpu-period="10000" (periodo de tiempo en microsegundos que puede usar la cpu el contenedor)
* --cpu-quota="5000"  (tiempo que puede usar la cpu el contendor durante el periodo anterior)
* Crear un usuario en el contenedor con permisos de sudo para que pueda ejecutar comandos con privilegios poniendo la contraceña, y luego uniciar el contenedor con este usuario usando --user nombre_usauario (que creaste en el contenedor).
