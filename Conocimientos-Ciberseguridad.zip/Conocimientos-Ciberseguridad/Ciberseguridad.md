Tags: #ciberseguridad 

La ciberseguridad es la práctica de defender las computadoras, los servidores, los dispositivos móviles, los sistemas electrónicos, las redes y los datos de ataques maliciosos. También se conoce como seguridad de tecnología de la información o seguridad de la información electrónica. El término se aplica en diferentes contextos, desde los negocios hasta la informática móvil, y puede dividirse en algunas categorías comunes.

Se puede dividir en:
* [[Pentesting]]
* [[Seguridad]]
* [[Programación]]
* [[Redes de Datos]]
* [[Sistemas Operativos]]
* 
