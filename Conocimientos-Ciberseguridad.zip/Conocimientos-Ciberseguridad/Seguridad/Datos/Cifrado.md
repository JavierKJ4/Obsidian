Tags: #cifrar #cifrado #datos #Seguridad

El cifrado en ciberseguridad es la conversión de datos de un formato legible a un formato codificado. Los datos cifrados solo se pueden leer o procesar luego de descifrarlos.

El cifrado es la base principal de la seguridad de datos. Es la forma más sencilla e importante para garantizar que la información de un sistema de computadora no pueda robarla ni leerla alguien que desee utilizarla con fines maliciosos.
## Cifrar en Linux

Se puede cifrar un archivo con multiples herramientas entre ellas:
* [[GNU Privacy Guard(gpg)]]
* [[OpenSSL]]

## Cifrar en Windows

Cuando cifras un archivo o una carpeta, **solo los usuarios que especifiques pueden ver su contenido**. Para el resto de personas es como el archivo estuviera corrupto y no podrán abrirlo. Las versiones básicas de Windows (Home, Start, Basic, Single License) no incluyen capacidades de cifrado.

Cifrar archivos y carpetas es muy sencillo en Windows. Un archivo cifrado no puede leerse en otro PC, aunque se copie, envíe por correo, etc. Ten en cuenta que tú mismo puedes tener problemas para leer un archivo cifrado si cambias de usuario o reinstalas Windows. 

**Para cifrar un archivo o carpeta**: 
* Haz clic con el botón derecho del ratón en él.
* En el menú desplegable, elige **Propiedades**. Si son varios archivos, puedes hacer esto mismo seleccionando todos los archivos y pulsando a la vez las teclas _Alt + Enter_ de tu teclado. Eso abrirá la ventana de propiedades combinada de todos los archivos o carpetas seleccionadas.
* A primera vista están las casillas para marcar un archivo como _Oculto_ o de _Solo lectura_, pero la casilla de cifrado está oculta. Para verla debes pulsar **Avanzados**.
* En las opciones avanzadas ya verás la casilla **Cifrar contenido para proteger datos**, que debes activar para cifrar este archivo.
* Después de pulsar _Aceptar_ en la ventana anterior es probable que veas una ventana. En ella se explica que tener un archivo cifrado en una carpeta sin cifrar podría hacer que otras personas accedan a su contenido a través de archivos temporales creados por programa de edición como Word o Photoshop. Depende de ti si quieres **Cifrar solo el archivo** o si quieres cifrar la carpeta que lo contiene también.

