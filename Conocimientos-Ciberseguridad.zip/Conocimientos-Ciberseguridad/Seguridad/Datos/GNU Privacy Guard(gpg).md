Tags: #cifrar #gpg #Seguridad

[GNU Privacy Guard](https://gnupg.org/) es una herramienta de código abierto con la que **puedes cifrar y descifrar archivos directamente**, así como crear tus propias claves y firmas digitales de manera autónoma. Usualmente los algoritmos de cifrado se utilizan para crear certificados de autenticidad en internet y encriptar nuestras comunicaciones. Sin embargo, GnuPG o GPG nos permite hacer este proceso de forma independiente y **mandar mensajes encriptados por el canal inseguro que queramos**.


**Cifrando archivos con una contraseña**  
En primer lugar para cifrar un fichero con gpg simplemente tendremos que escribir en nuestra consola:  
  
>gpg -c file.to.encrypt

Con la opción "-c" usaremos un cifrado simétrico usando una contraseña o _passphrase_. El cifrado simétrico por defecto es CAST5.

Con la opción --cipher-algo nombre (En nombre pones el algoritmo que quieres usar)
Algoritmos: IDEA, 3DES, CAST5, BLOWFISH, AES, AES192, AES256, TWOFISH, CAMELLIA128, CAMELLIA192, CAMELLIA256

Luego, para descifrar el fichero simplemente ejecutaremos:  
  
>gpg filetoencrypt.gpg

Y se creará un archivo con el contenido decifrado.

Si quieres poner directamente la _passphrase_ se puede usar --passphrase:

>gpg filetoencrypt.gpg --passphrase pass

En pass colocas la _passphrase_.

[Cifrando archivos con una clave privada](https://www.hackplayers.com/2016/12/cifrar-y-descifrar-archivos-y-dirs-linux.html)