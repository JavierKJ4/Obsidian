Tags: #Seguridad #permisos

Visualización de los permisos:
drwxrwxrwx

d -> directorio o no
1er rwx -> usuario propietario
2do rwx -> grupo
3er rwx -> otros usuarios

> chmod 777 archivo

Modificaciones
0 --> ---
1 --> --x
2 --> -w-
3 --> -wx
4 --> r--
5 --> r-x
6 --> rw-
7 --> rwx

Variante del chmod

> chmod u+rwx archivo
> chmod g+rwx archivo
> chmod o+rwx archivo

Puedes utilizar el + o - para dar y quitar permisos