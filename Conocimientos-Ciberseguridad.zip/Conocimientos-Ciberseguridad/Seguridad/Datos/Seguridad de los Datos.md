Tags: #seguridad #datos

La seguridad de los datos está compuesta por:
* [[Cifrado]]
* [[Copias de seguridad]]
* [[Permisos]]
