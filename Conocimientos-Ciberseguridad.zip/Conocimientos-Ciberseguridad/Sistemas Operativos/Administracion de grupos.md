Tags: #Sistemas_operativos 

>addgroup nombre_gr

creas un grupo.

>delgroup nombre_gr

Elimina un grupo que no contenga ningun usuario, para eliminar un grupo con usuarios dentro tienes que sacar a los usuarios.

>groupmod  -n nuevo_nombre  nombre_gr

>gpasswd  nombre_gr

* -a  agrega un usuario a un grupo
* -d  saca a un usuario de un grupo
* sin parametros cambia la contraseña del grupo.

>groups nombre_usr

Ves los  grupos a los que pertenece un usuario.

