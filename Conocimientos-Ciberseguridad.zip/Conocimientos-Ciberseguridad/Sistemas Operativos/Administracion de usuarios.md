Tags: #Sistemas_operativos 

>adduser  nombre_usr

Agrega un usuario.

>deluser --remove-home nombre_usr 

Elimina un usuario y su carpeta de home.

>usermod -l otro_nombre  -d /home/otro_nombre

Cambia el nombre del usuario y su directorio home.

>passwd nombre_usr

*  -l  bloquea la cuenta de un usuario
* -u  activa la cuenta de un usuario
* sin parametros cambia el password de un usuario.

>id nombre_usr

Devuelve informacion relacionada a la identificacion del usuario.


>who -u

Muestra la lista de ususario conectados.

>su -c comando ususario

Permite ejecutar un comando como otro usuario colocando la contraceña pero sin tener que cambiar de usuario.

>finger nombre_usuario

Muestra informacion sobre ese usuario.



