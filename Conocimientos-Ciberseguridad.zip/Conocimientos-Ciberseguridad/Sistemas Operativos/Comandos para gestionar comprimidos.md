Tags: #Sistemas_operativos 

>tar 

* -c (Crea un fichero)
* -z (Utiliza gzip para comprimir)
* -v (verbose)
* -f (Especifica el nombre del fichero de salida)

Ejemplo:
> tar -czvf nombre_fichero_resultante.tar  ruta_o_fichero_a_comprimir

> tar -xzvf nombre_fichero_a_descomprimir.tar


>gzip nombre_del_fichero_a_comprimir
>gzip -d nomb_fichero_descomprimir

>zip nomb_fich_resultante nomb_fich_a_comp
>unzip nombre.zip



