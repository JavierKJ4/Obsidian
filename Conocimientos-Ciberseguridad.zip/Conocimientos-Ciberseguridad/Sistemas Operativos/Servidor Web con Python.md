Tags: #Sistemas_operativos 

>python3 -m http.server  puerto

Se crea el servidor web en la direccion en la que ejecutaste el comando.

>wget IP/nombre_del_archivo 

Descarga el fichero de el servidor web.

