Tags: #Sistemas_operativos 

Estos tres estan presentes en todos los comandos que ejecutas.

Los descriptores son un numero asociado a un recurso, es decir con este numero puedes referenciar a un recurso en especifico y realizar acciones sobre estos.
## stdin
Descriptor: 0
Datos de entrada de un comando. Es decir todo lo que presiones en el teclado es parte del input.
## stdout
Descriptor: 1
Datos de salida de un comando.

## stderr
Descriptor: 2
Datos de error de un comando.

El descriptor & es el 1 y el 2 juntos.