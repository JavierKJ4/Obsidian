Tags: #Sistemas_operativos 

>ps

Muestra los procesos activos.
* a (muestra los procesos de todos los usuarios)
* u (De un usuario especifico)
* x (incluye los procesos que no tengan una terminal asociada)

>top 

Muestra los procesos en ejecucion y su consumo de recursos

>kill 

Envia señales a un proceso
syntaxis : kill señal PID_del_proceso
señales:
* 1 (SIGHUP)(reinicia un proceso)
* 2 (SIGINT)(Interrumpe, equivalente a Ctrl+C)
* 3 (SIGQUIT)(sale del proceso, genera volcado de memoria)
* 4 (SIGILL)(indica una istruccion ilegal)
Captura de pantalla:


