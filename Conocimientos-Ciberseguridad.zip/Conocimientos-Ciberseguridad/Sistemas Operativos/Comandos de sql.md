Tags: #Sistemas_operativos 

## Definiendo cómo es almacenada la información.

- [CREATE DATABASE](https://mariadb.com/kb/en/create-database/) se utiliza para crear una nueva base de datos vacía.
- [DROP DATABASE](https://mariadb.com/kb/en/drop-database/) se utiliza para eliminar completamente una base de datos existente.
- [CREATE TABLE](https://mariadb.com/kb/en/create-table/) se utiliza para crear una nueva tabla, donde la información se almacena realmente.
- [ALTER TABLE](https://mariadb.com/kb/en/alter-table/) se utiliza para modificar una tabla ya existente.
- [DROP TABLE](https://mariadb.com/kb/en/drop-table/) se utiliza para eliminar por completo una tabla existente.

## Manipulando los datos.

- [SELECT](https://mariadb.com/kb/es/select) se utiliza cuando quieres leer (o seleccionar) tus datos.
- [INSERT](https://mariadb.com/kb/en/insert/) se utiliza cuando quieres añadir (o insertar) nuevos datos.
- [UPDATE](https://mariadb.com/kb/en/update/) se utiliza cuando quieres cambiar (o actualizar) datos existentes.
- [DELETE](https://mariadb.com/kb/en/delete/) se utiliza cuando quieres eliminar (o borrar) datos existentes.
- [REPLACE](https://mariadb.com/kb/en/replace/) se utiliza cuando quieres añadir o cambiar (o reemplazar) datos nuevos o ya existentes.
- [TRUNCATE](https://mariadb.com/kb/en/truncate/) se utiliza cuando quieres vaciar (o borrar) todos los datos de la plantilla.

### Un ejemplo sencillo.

CREATE DATABASE mydb;
USE mydb;
CREATE TABLE mitabla ( id INT PRIMARY KEY, nombre VARCHAR(20) );
INSERT INTO mitabla VALUES ( 1, 'Will' );
INSERT INTO mitabla VALUES ( 2, 'Marry' );
INSERT INTO mitabla VALUES ( 3, 'Dean' );
SELECT id, nombre FROM mitabla WHERE id = 1;
UPDATE mitabla SET nombre = 'Willy' WHERE id = 1;
SELECT id, nombre FROM mitabla;
DELETE FROM mitabla WHERE id = 1;
SELECT id, nombre FROM mitabla;
DROP DATABASE mydb;
SELECT count(1) from mitabla; da el número de registros en la tabla