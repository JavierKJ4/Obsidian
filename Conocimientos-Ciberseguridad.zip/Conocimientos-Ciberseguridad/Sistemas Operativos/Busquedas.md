Tags: #Sistemas_operativos 

>find

* -name "nombre.txt"
* -type f (tipo fichero)

>grep

Se utiliza para filtrar en archivos por una palabra o expresion.

* -i (insensible a mayusculas y minusculas)

>locate

Busca un fichero en su base de datos que es como una copia del sistema y se actualiza una vez al dia en una tarea cron.
  

