Tags: #Sistemas_operativos 

> show databases

Muestra las bases de datos.

>use nombre

Selecciona una base de datos.

>show tables

Muestra las tablas.

>describe nombre_tabla

Te muestra las columnas de una tabla.

[[Comandos de sql]]

Para obtener información de las tablas.
