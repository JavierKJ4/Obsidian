Tags: #Consola #Linux #Sistemas_operativos




Contenido:
* [[nc (Netcat)]]
* [[gzip]]
* [[Mysql]]
* [[curl]]
* [[lsb_release]]
* [[tail]]
* [[Administracion de usuarios]]
* [[Administracion de grupos]]
* [[Administracion de paquetes]]
* [[Comandos para gestionar comprimidos]]
* [[Operadores de consola]]
* [[Busquedas]]
* 