Tags: #Sistemas_operativos 

>gzip -d archivo.gz 

Descomprime el archivo.gz

