Tags: #Sistemas_operativos 

Ruta absoluta:
* Siempre va a empezar desde la /
Ejemplo: /home/kali/archivo.txt



Ruta relativa:
* Nunca empieza por la /
Ejemplo: ../archivo.txt

