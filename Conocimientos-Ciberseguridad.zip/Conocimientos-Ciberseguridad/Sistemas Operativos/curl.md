Tags: #Sistemas_operativos 

Se utiliza para hacer peticiones  a servidores HTTP.

>curl URL 

Devuelve todas las etiquetas, la pagina de la respuesta.

>curl URL -i 

Devuelve una estructura json con los encabezados.

>curl URL -x GET 

Cambia el método de la petición HTTP.


