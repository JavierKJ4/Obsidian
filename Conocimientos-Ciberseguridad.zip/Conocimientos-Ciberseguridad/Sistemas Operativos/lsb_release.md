Tags: #Sistemas_operativos 

>lsb_release -a 

Muestra la version de el linux que está corriendo.

Nota: si la version de linux no es la misma en todos los puertos abiertos de la maquina objetivo eso significa que hay servicios en contenedores.




