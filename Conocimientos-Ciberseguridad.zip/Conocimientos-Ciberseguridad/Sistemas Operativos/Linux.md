Tags: #Sistemas_operativos

Contemido:
* [[Comandos de consola de linux]]
* 