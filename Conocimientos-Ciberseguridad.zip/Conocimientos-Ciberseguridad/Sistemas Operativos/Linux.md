Tags: #Sistemas_operativos

En linux un emulador de terminal es un programa que emula una terminal fisica y es la que ejecuta los diferentes tipos de shells(sh, bash, zsh).

Ficheros importantes:
* /etc/passwd (Contiene informacion de los usuarios del sistema)
* /etc/group (Contiene los grupos del sistema)
* /etc/shadow (Almacena las contrceñas de los usuarios en formato encriptado)
* /etc/fstab (Como y donde se montan los sistemas de archivos)
* /etc/network/interfaces (Configuracion de red)
* /etc/hostname (Nombre del host del sistema)
* /etc/resolv.conf (Se definen los servidores DNS que el sistema utiliza.)

Directorios importantes:
* /boot/ (Contiene los ficheros necesarios para el arranque del sistema)
* /etc/ (Contiene los ficheros de configuracion del sistema y de las aplicaciones)
* /var/ (Contiene los ficheros de datos de variables como los registros del sistema o logs y las bases de datos)
* /usr/ (contiene los ficheros compartidos con todos los usuarios incluyendo aplicaciones( /usr/bin/ ) y las librerias( /usr/lib/ ).)
* /home/ (Contiene subdirectorios personales de los usuarios del sistema)
* /root/ (Es como el directorio /home/ pero solo para root)
* /tmp/ (Se almacenan los ficheros temporales)
* /dev/ (contiene ficheros que representan dispositivos de hardware)
* /sbin/ (Contiene los ejecutables para el arranque del sistema)
Directorios que interactuan con el kernel de GNU/linux y no con el disco duro en si:
* /proc/ (Informacion de los procesos en ejecucion)
* /sys/ (Son directorios que representan el hardware del sistema)


Variables de entorno:
>env

Se utiliza para ver las variables de entorno.

Comandos para manipular variables de entorno:
>echo $Nombre (Puedes ver el valor de cualquier variable de forma individual)
>export nombre=valor (Define una variable nueva o modifica una existente)
>unset nombre (Elimina una variable de entorno)

Variables importantes:
* PATH (Son las rutas donde el sistema busca los ejecutables)
* HOME (Directorio home del usuario)
* SHELL(La shell del usuario actual)
* LANG (Configuracion de idioma)

Nota: Si quieres que una variable de entorno que crees se quede de forma permanente tienes que entrar al directorio home del ususario que estas utilizando y buscar el fichero oculto de ls shell (.zshrc, .bashrc, .shrc) y escribir dentro el comando export con la variable y el valor que quieres que se quede permanente.




Contenido:
* [[Comandos de consola de linux]]
* [[Servidor Web con Python]]
* [[Rutas absolutas y relativas]]
* [[stderr, stdin, stdout]]
* [[Redes en linux]]
* [[Gestion de procesos]]
* 