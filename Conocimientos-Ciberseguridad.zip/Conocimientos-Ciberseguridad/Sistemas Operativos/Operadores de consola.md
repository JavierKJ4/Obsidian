Tags: #Sistemas_operativos 

* && (es como en AND pero aqui lo que hace es que solo si se ejecuta el primer comando se ejecuta el segundo)
* ||  (Es como el OR pero lo que hace es que solo si no se ejecuta el primer comando se ejecuta el segundo)
* ! (invierte el resultado del comando)
* ; (permite ejecutar comandos uno despues del otro)
* & (mandas el comando a segundo plano)
* | (hace redireciones de un comando a otro)