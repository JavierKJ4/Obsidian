Tags: #Sistemas_operativos 

>tail -f  nombre_fichero

Muestra en tiempo real el final del archivo, es util si vas a revisar un archivo de logs para ver que es lo ultimo que se ejecuta.