Tags: #Sistemas_operativos

Se divide en:
* [[Linux]]
* [[Windows]]