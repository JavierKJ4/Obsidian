Tags: #Sistemas_operativos 

Nombres tradicionales:
Pueden cambiar al reiniciar o al conectarnos en condiciones distintas.
Ejemplo: wlan0, wlan1, eth0, eth1

Nombres predictivos:
No pueden cambiar al reiniciar o al conectarnos en condiciones distintas.
Ejemplo: enp2s0

* en  : ethernet
* wl  : wlan
* ww  : wwan

* p(# de bus)
* s(# de dispositivo en ese bus)

Con la union de estos es que se crean las interfaces como la del ejemplo.

>ifconfig

Muestra la informacion de las interfaces de red.

>ip 

* a (muestra las interfaces de red, como ifconfig pero mas feo)
* route (muestra las rutas por las que viajan los paquetes)
	* add (agregas una ruta ) Ej: ip route add 192.168.2.0/24  via  10.0.2.4 
	 La primera IP es el destino , via es un parametro y la ultima IP es la puerta de enlace.

>netstat 

Ver las conecciones de red que estan activas.
* -t (Muestra las TCP)
* -u (UDP)
* -l (Muestra los puertos en escucha)
* -p (Muestra el PID)
* -e (Informacion extendida)

>ping 

Envia paquetes de tipo ICMP para verificar la conexion.

>traceroute

Ves el recorrido de los paquetes.

>nslookup

Hace consultas al servidor DNS
* -type=tipo_registro (busca registros de ese tipo en el servidor dns para el dominio especificado) Ej: nslookup -type=MX google.com