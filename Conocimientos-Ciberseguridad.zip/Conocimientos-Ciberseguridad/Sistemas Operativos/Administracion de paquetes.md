Tags: #Sistemas_operativos 

Los paquetes son softwares guardados en un archivo y que puede necesitar o no dependencias.

>apt 

* update (actualizas la lista de paquetes, no instala)(Este tambien puede traer problemas)
* upgrade (instala los paquetes que estan en la lista)(Usar esto en kali puede provocar problemas devido a la cantidad de herramientas que tiene kali.)
* full-upgrade (actualiza completamente, es igual a upgrade pero maneja mejor las dependencias)
* install (instalar paquetes)
* remove (eliminas paquetes)
* auto-remove (elimina dependencias que no se estan usando)

En kali es mejor instalar las cosas manuales para evitar problemas.
Las dependencias son paquetes que otros paquetes necesitan para funcionar.

>dpkg

Solo maneja paquetes tipo deb.

* -i (instala un paquete)
* -l (lista de los instalados)
* -p (elimina un paquete)

>apt-get

Version antigua de apt pero un poco mas estable.
* dist-upgrade (hace lo que upgrade pero maneja mejor los errores con dependencias y sus actualizaciones.)

>apt-cache

Muestra datos de un paquete 
* depends (muestra las dependencias de un paquete)
* policy (muestra las politicas de un paquete)

>dpkg-reconfigure

Reconfigura paquetes ya instalados incluyendo los del kernel que vienen por defecto.

Fichero importante:
* /etc/apt/source.list (contiene la ruta de los repositorios)
* /etc/apt/source.list.d  (Este se utiliza para agregar nuevos repositorios sin afectar el que esta por defecto.)