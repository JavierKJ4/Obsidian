Tags: #nc #netcat #Sistemas_operativos

>nc -lvp puerto

Para ponerse a la escucha por un puerto.


>nc -v IP puerto 

Para conectarse a un puerto abierto  de una IP específica.


El comando `nc` acepta, entre otras, las siguientes opciones básicas:

- `**-l**`: Sirve para que Netcat abra un puerto y se mantenga ala escucha. Se aceptará una única conexión de un único cliente antes de cerrarse.
- `**-k**`: Se usa junto con la opción `-l` con el objetivo de que el puerto ser mantenga abierto tras recibir una conexión, a la espera de más conexiones.
- `**-u**`: Permite abrir puertos con el protocolo UDP en vez de abrirlos mediante el protocolo TCP.
- `**-p**`: Esta opción permite especificar el puerto al que conectarse.
- `**-v**`: Se usa para mostrar información acerca de la conexión.
- `**-t**`:  Respuestas compatibles con sesiones de Telnet

