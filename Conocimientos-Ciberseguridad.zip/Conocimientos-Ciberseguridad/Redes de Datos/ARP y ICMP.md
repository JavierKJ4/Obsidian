Tags: #ARP #ARP  #Redes_de_Datos

## ARP
Protocolo de resolución de direcciones. Se encarga de conseguir la dirección de hardware que corresponde a una IP.

## ICMP
Se utiliza dentro de una red para comunicar problemas con la transmisión de datos.