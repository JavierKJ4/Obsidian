Tags: #Redes_de_Datos 

Es un servicio de correos, si esta abierto, la carpeta /var/mail/user contiene los mails de ese usuario.
Para enviar un correo se utiliza:
```bash
telnet IP port
```
Dentro colocas:
```
MAIL FROM:nombre
RCPT TO:usuario_destino
DATA (escribes el texto y cuando termines pones un .)
```