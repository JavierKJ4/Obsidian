Tags: #Redes #Datos #Redes_de_Datos

Conocimientos sobre redes:
* [[Direcciones IP y MAC]]
* [[TCP, UDP y Three-Way Handshake]]
* [[Máscara de Red]]
* [[DNS y DHCP]]
* [[Puertos]]
* [[ARP y ICMP]]
* 