Tags: #puertos #Redes_de_Datos

En el contexto de la informática, un puerto es un número de identificación que se utiliza para distinguir diferentes canales de comunicación en una misma máquina o entre máquinas en una red. Imagina un puerto como una puerta de entrada específica en un edificio con muchas habitaciones. Cada habitación representa un servicio o programa en una computadora. Los puertos permiten que múltiples servicios se ejecuten en la misma máquina sin entrar en conflicto.

Existen en todas las computadoras 65535.

- **Puerto 80 (HTTP):** se utiliza para las solicitudes web. Cuando escribes una dirección web en tu navegador, como «https://www.sudominio.com», tu navegador utiliza el puerto 80 para comunicarse con el servidor web de ese sitio y solicitar la página.
- **Puerto 443 (HTTPS):** similar al puerto 80, pero se utiliza para conexiones seguras. El HTTPS cifra la información entre el cliente y el servidor para proteger la privacidad y la seguridad de los datos.
- **Puerto 22 (SSH):** SSH (Secure Shell) se utiliza para acceder de forma segura a servidores y dispositivos remotos.
- **Puerto 21 (FTP):** el Protocolo de Transferencia de Archivos (FTP) utiliza el puerto 21 para la transferencia de archivos entre computadoras a través de una red.
- **Puerto 25 (SMTP):** este es el puerto utilizado para enviar correos electrónicos. Los servidores de correo electrónico utilizan el protocolo SMTP para transmitir mensajes.
- **Puerto 587 (Submission):** este puerto se utiliza específicamente para el envío de correos electrónicos desde clientes de correo a servidores de correo saliente (SMTP). Se ha convertido en una opción más segura que el puerto 25 para el envío de correos electrónicos debido a su requerimiento de autenticación y soporte para cifrado TLS/SSL.
- **Puerto 110 (POP3):** se utiliza para la recepción de correos electrónicos desde un servidor de correo entrante. Descarga los correos electrónicos en el cliente y, por defecto, elimina las copias del servidor después de su descarga.
- **Puerto 995 (POP3S):** similar al puerto 110, pero utiliza cifrado SSL/TLS para una comunicación segura entre el cliente y el servidor POP3.
- **Puerto 143 (IMAP):** utilizado para la recepción de correos electrónicos desde un servidor de correo entrante. A diferencia de POP3, IMAP mantiene una copia de los correos electrónicos en el servidor, lo que permite el acceso a través de múltiples dispositivos.
- **Puerto 993 (IMAPS):** similar al puerto 143, pero utiliza cifrado SSL/TLS para una comunicación segura con el servidor IMAP.