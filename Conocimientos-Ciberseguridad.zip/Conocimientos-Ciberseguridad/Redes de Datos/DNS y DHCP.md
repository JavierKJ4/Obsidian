Tags: #DNS #DHCP #Redes_de_Datos

## DNS
Dominios aptos para la lectura humana. Los servidores DNS se encargan de convertir los dominios en direcciones IP, gracias a esto no hay que memorizar la ip de google para acceder a ella por ejemplo.

## DHCP
Protocolo cliente-servidor que proporciona automaticamente una IP a cada cliente conectado ademas de las configuraciones de la máscara de red y puerta de enlace.

