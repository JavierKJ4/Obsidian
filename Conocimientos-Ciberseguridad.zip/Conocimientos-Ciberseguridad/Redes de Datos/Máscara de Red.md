Tags: #Máscara #Red #Redes_de_Datos

Define que parte de la IP corresponde a la red y al host.

Nota: dos ordenadores con diferentes subredes no pueden comunicarse.

Formas de escribir la máscara de red:
* 10.10.10.10/24
* 10.10.10.10/255.255.255.0

/24 -----> 255.255.255.0
/16 -----> 255.255.0.0
/8 -----> 255.0.0.0 

