Tags: #TCP #UDP #Three-Way-Handshake #Redes_de_Datos

## TCP:
Da soporte a FTP, HTTP, HTTPS, SMTP, SSH y otros.

Nota: los paquetes ACK garantizan que llegaron los paquetes anteriores.

### Three-Way-Handshake:
Es la forma en la que se establece la conexión en TCP.

TCP Cliente                                  TCP Servidor
SYN Seq(n)---------------------------->
   <-----------------SYN Seq(m), ACK(n+1)
ACK Seq(n+1)-------------------------->

De esta forma se completa una conexión TCP.



TCP Cliente                                  TCP Servidor
Flag(1)---------------------------->
   <---------------------------- ACK
   <---------------------------- FIN

Asi se finaliza la conexión normalmente.

TCP Cliente                                  TCP Servidor
 RST(1)---------------------------->

Asi se finaliza la conexión de forma agresiva.

Flags:
* ACK
* PSH (Apura el envio de datos)
* RST (Resetea, aborta la conexión)
* SYN (Esctablece la conexión)
* FIN (Finaliza la conexión)
* URG (Da prioridad al paquete)
## UDP
No orientado a la conexión.(No establece ni finaliza la conexión).
No confiable porque no recupera errores.
Pero es mas rápido.



