Tags: #IP #Direcciones #MAC #Redes_de_Datos

Direcciones IP:
IPv4:
Son de 32bits.
Ejemplo: 10.10.10.10

IPv6:
Son de  128bits
Ejemplo: 2610:18:cc0:0000:0000:1:8010

Direcciones MAC:
01:3A:1D:54:GB:32

Diferencias entre OUI y UAA:
* OUI: Las tres primeras divisiones. Es el identificador unico del fabricante.
Ejemplo: 01:3A:1D
* UAA: Las tres ultimas divisiones. Es el identificador unico del producto.
Ejemplo: 54:GB:32

Comandos relacionados:
>ifconfig

Muestra las conexiones a internet o redes locales.

>route -n 

Para obtener el Gateway.

>arp-scan --interface=eth0 10.10.10.1/24 

Realiza un escaneo por una interfaz usando el Gateway para buscar IP y MAC de los hosts conectados a la red.
